<?php
/**
 * 个性化日期显示
 * @static
 * @access public
 * @param datetime $times 日期
 * @return string 返回大致日期
 * @example 示例 ueTime('')
 */
function ueTime($times) {
    if ($times == '' || $times == 0) {
        return false;
    }
    //完整时间戳
    $strtotime = is_int($times) ? $times : strtotime($times);
    $times_day = date('Y-m-d', $strtotime);
    $times_day_strtotime = strtotime($times_day);

    //今天
    $nowdate_str = strtotime(date('Y-m-d'));

    //精确的时间间隔(秒)
    $interval = time() - $strtotime;

    //今天的
    if ($times_day_strtotime == $nowdate_str) {

        //小于一分钟
        if ($interval < 60) {
            $pct = sprintf("%d秒前", $interval);
        }
        //小于1小时
        elseif ($interval < 3600) {
            $pct = sprintf("%d分钟前", ceil($interval / 60));
        } else {
            $pct = sprintf("%d小时前", floor($interval / 3600));
        }
    }
    //昨天的
    elseif ($times_day_strtotime == strtotime(date('Y-m-d', strtotime('-1 days')))) {
        $pct = '昨天' . date('H:i', $strtotime);
    }
    //前天的
    elseif ($times_day_strtotime == strtotime(date('Y-m-d', strtotime('-2 days')))) {
        $pct = '前天' . date('H:i', $strtotime);
    }
    //一个月以内
    elseif ($interval < (3600 * 24 * 30)) {
        $pct = date('m月d日', $strtotime);
    }
    //一年以内
    elseif ($interval < (3600 * 24 * 365)) {
        $pct = date('m月d日', $strtotime);
    }
    //一年以上
    else {
        $pct = date('Y年m月d日', $strtotime);
    }
    return $pct;
}

/**
     * 转换时间
     * @param unknown $createTime
     * @return string
     */
    private function _getUpdTime($updTime, $nowTime) {
        
        $_itime = $nowTime - $updTime; //间隔秒数
        

        $_day = 7; //至少要显示多少天前
        

        $_daytimes = 86400 * $_day;
        if ($_itime > $_daytimes) {
            //大于24小时,返回日期时间
            return date ( "Y-m-d", $updTime );
        }
        
        $day = floor ( $_itime / 86400 );
        if ($day) {
            return $day . '天前';
        }
        
        //24小时内返回小时数
        $hour = floor ( $_itime / 3600 );
        if ($hour) {
            return $hour . '小时前';
        }
        
        //1小时内 返回分钟数
        $minute = floor ( $_itime / 60 );
        if ($minute) {
            return $minute . '分钟前';
        }
        
        //1分钟内返回秒数
        return $_itime . '秒前';
    }


    /**
     * 流格式
     * @param      int $time
     * @access     public
     * @return     string
     * @update     2014/3/17
    */
    public static function timeFlow( $time, $format = 'Y-m-d' ) {
        $time = intval( $time );
        //一周前
        $t = time();
        $weektime = $t - 7*24*60*60;
        $daytime = $t - 24*60*60;
        $hourtime = $t - 60*60;
        $minutetime = $t - 60;

        if ( $time < $weektime ) {
            return date( $format , $time );
        } elseif ( $time < $daytime ) {
            return intval( ( $t - $time ) / (24*60*60) ) . '天前';
        } elseif ( $time < $hourtime ) {
            return intval( ( $t - $time ) / ( 60*60 )  ) . '小时前';
        } elseif ( $time < $minutetime ) {
            return intval( ( $t - $time ) /  60  ) . '分钟前';
        } else {
            return $t - $time . "秒前";
        }    
    }